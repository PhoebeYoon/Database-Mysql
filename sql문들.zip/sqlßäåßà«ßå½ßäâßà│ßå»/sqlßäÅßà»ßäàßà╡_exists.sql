use market_db;
select * from sales;
select * from orders;


SELECT * FROM sales S
	WHERE NOT EXISTS 
		(SELECT * FROM orders  O
			WHERE sales.order_date = orders.order_date);   
            
            
SELECT * FROM sales  
	WHERE EXISTS 
		(SELECT * FROM orders  
			WHERE sales.order_date = orders.order_date);  
            
SELECT * FROM sales S -- sales 를 S로 칭하겠습니다 
	WHERE NOT EXISTS 
		(SELECT * FROM orders  O
			WHERE S.order_date = O.order_date); 